require('dotenv').config()

const { Client, GatewayIntentBits } = require('discord.js')

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
})

client.once('ready', () => {
  console.log(`☘️ Clover Bot online: ${client.user.tag}`)
})

client.on('messageCreate', async message => {
  if(message.author.bot) return

  if(message.content === '!ping'){
    message.reply('🏓 Pong!')
  }

  if(message.content === '!clover'){
    message.reply('☘️ Clover Bot ativo!')
  }
})

client.login(process.env.TOKEN)
